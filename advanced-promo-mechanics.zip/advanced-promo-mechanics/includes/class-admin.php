<?php
namespace APM;

class Admin {
    private Rules_Store $rules_store;
    private Logger $logger;

    public function __construct( Rules_Store $rules_store, Logger $logger ) {
        $this->rules_store = $rules_store;
        $this->logger      = $logger;
    }

    public function init() : void {
        add_action( 'admin_menu', [ $this, 'register_menu' ] );
        add_action( 'add_meta_boxes', [ $this, 'register_meta_box' ] );
        add_action( 'save_post_apm_rule', [ $this, 'save_rule_meta' ], 10, 2 );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function register_menu() : void {
        add_submenu_page(
            'woocommerce',
            __( 'Promozioni Avanzate', 'advanced-promo-mechanics' ),
            __( 'Promozioni Avanzate', 'advanced-promo-mechanics' ),
            'manage_woocommerce',
            'apm-rules',
            [ $this, 'render_page' ]
        );
    }

    public function render_page() : void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $rules = $this->rules_store->get_rules();
        $settings = get_option( 'apm_settings', [] );

        include APM_PLUGIN_DIR . 'includes/views/admin-page.php';
    }

    public function register_meta_box() : void {
        add_meta_box(
            'apm_rule_meta',
            __( 'Dettagli regola', 'advanced-promo-mechanics' ),
            [ $this, 'render_meta_box' ],
            'apm_rule',
            'normal',
            'high'
        );
    }

    public function render_meta_box( $post ) : void {
        wp_nonce_field( 'apm_rule_nonce', 'apm_rule_nonce' );
        $data = $this->rules_store->get_rule_meta( $post->ID );
        include APM_PLUGIN_DIR . 'includes/views/meta-box.php';
    }

    public function save_rule_meta( int $post_id, $post ) : void {
        if ( ! isset( $_POST['apm_rule_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['apm_rule_nonce'] ) ), 'apm_rule_nonce' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $payload = $_POST['apm_rule'] ?? [];
        $this->rules_store->save_rule_meta( $post_id, $payload );
        $this->logger->debug( 'Saved rule meta', [ 'rule_id' => $post_id ] );
    }

    public function enqueue_assets( string $hook ) : void {
        if ( str_contains( $hook, 'apm' ) ) {
            wp_enqueue_style( 'apm-admin', APM_PLUGIN_URL . 'assets/admin/css/admin.css', [], APM_VERSION );
            wp_enqueue_script( 'apm-admin', APM_PLUGIN_URL . 'assets/admin/js/admin.js', [ 'wp-i18n', 'wp-components', 'wp-element' ], APM_VERSION, true );
        }
    }
}
