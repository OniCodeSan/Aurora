<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$type       = $data['type'] ?? 'free_gift';
$enabled    = ! empty( $data['enabled'] );
$priority   = $data['priority'] ?? 10;
$conditions = $data['conditions'] ?? [];
$config     = $data['config'] ?? [];
?>
<p>
    <label>
        <input type="checkbox" name="apm_rule[enabled]" value="1" <?php checked( $enabled ); ?> />
        <?php esc_html_e( 'Attiva regola', 'advanced-promo-mechanics' ); ?>
    </label>
</p>
<p>
    <label><?php esc_html_e( 'Tipo regola', 'advanced-promo-mechanics' ); ?></label>
    <select name="apm_rule[type]">
        <option value="free_gift" <?php selected( $type, 'free_gift' ); ?>><?php esc_html_e( 'Omaggio', 'advanced-promo-mechanics' ); ?></option>
        <option value="bogo" <?php selected( $type, 'bogo' ); ?>><?php esc_html_e( '2x1 meno caro', 'advanced-promo-mechanics' ); ?></option>
        <option value="three_two" <?php selected( $type, 'three_two' ); ?>><?php esc_html_e( '3x2', 'advanced-promo-mechanics' ); ?></option>
        <option value="quantity" <?php selected( $type, 'quantity' ); ?>><?php esc_html_e( 'Sconto quantità', 'advanced-promo-mechanics' ); ?></option>
    </select>
</p>
<p>
    <label><?php esc_html_e( 'Priorità', 'advanced-promo-mechanics' ); ?></label>
    <input type="number" name="apm_rule[priority]" value="<?php echo esc_attr( $priority ); ?>" min="0" />
</p>

<h4><?php esc_html_e( 'Condizioni', 'advanced-promo-mechanics' ); ?></h4>
<p>
    <label><?php esc_html_e( 'Min subtotale', 'advanced-promo-mechanics' ); ?></label>
    <input type="number" step="0.01" name="apm_rule[conditions][min_subtotal]" value="<?php echo esc_attr( $conditions['min_subtotal'] ?? '' ); ?>" />
</p>
<p>
    <label><?php esc_html_e( 'Min quantità', 'advanced-promo-mechanics' ); ?></label>
    <input type="number" name="apm_rule[conditions][min_qty]" value="<?php echo esc_attr( $conditions['min_qty'] ?? '' ); ?>" />
</p>
<p>
    <label><?php esc_html_e( 'Coupon richiesto', 'advanced-promo-mechanics' ); ?></label>
    <input type="text" name="apm_rule[conditions][coupon]" value="<?php echo esc_attr( $conditions['coupon'] ?? '' ); ?>" />
</p>

<h4><?php esc_html_e( 'Configurazione', 'advanced-promo-mechanics' ); ?></h4>
<p>
    <label><?php esc_html_e( 'Limite per ordine', 'advanced-promo-mechanics' ); ?></label>
    <input type="number" name="apm_rule[config][limit_per_order]" value="<?php echo esc_attr( $config['limit_per_order'] ?? '' ); ?>" />
</p>
<p>
    <label>
        <input type="checkbox" name="apm_rule[config][repeatable]" value="1" <?php checked( ! empty( $config['repeatable'] ) ); ?> />
        <?php esc_html_e( 'Ripetibile', 'advanced-promo-mechanics' ); ?>
    </label>
</p>
<p>
    <label>
        <input type="checkbox" name="apm_rule[config][exclude_discounted]" value="1" <?php checked( ! empty( $config['exclude_discounted'] ) ); ?> />
        <?php esc_html_e( 'Escludi prodotti già in promo', 'advanced-promo-mechanics' ); ?>
    </label>
</p>
<p>
    <label><?php esc_html_e( 'Prodotti omaggio (ID separati da virgola)', 'advanced-promo-mechanics' ); ?></label>
    <input type="text" name="apm_rule[config][gift_products][]" value="<?php echo esc_attr( implode( ',', $config['gift_products'] ?? [] ) ); ?>" />
</p>
<p>
    <label><?php esc_html_e( 'Scaglioni scontro (JSON)', 'advanced-promo-mechanics' ); ?></label>
    <textarea name="apm_rule[config][tiers_raw]" rows="4"><?php echo esc_textarea( wp_json_encode( $config['tiers'] ?? [] ) ); ?></textarea>
</p>
