<?php
namespace APM;

use APM\Admin;
use APM\Rules_Store;
use APM\Rules_Engine;
use APM\Logger;

class Plugin {
    private Admin $admin;
    private Rules_Store $rules_store;
    private Rules_Engine $engine;
    private Logger $logger;

    public function init() : void {
        $this->logger      = new Logger();
        $this->rules_store = new Rules_Store( $this->logger );
        $this->engine      = new Rules_Engine( $this->rules_store, $this->logger );
        $this->admin       = new Admin( $this->rules_store, $this->logger );

        add_action( 'init', [ $this, 'register_post_type' ] );
        add_action( 'init', [ $this, 'register_settings' ] );
        add_action( 'init', [ $this, 'maybe_flush_cache' ] );

        add_action( 'woocommerce_before_calculate_totals', [ $this->engine, 'apply_cart_adjustments' ], 20 );
        add_action( 'woocommerce_cart_calculate_fees', [ $this->engine, 'apply_cart_fees' ], 20, 1 );

        add_action( 'woocommerce_cart_updated', [ $this->engine, 'invalidate_cart_cache' ] );
        add_action( 'woocommerce_checkout_order_processed', [ $this->engine, 'invalidate_cart_cache' ] );

        $this->admin->init();
    }

    public function register_post_type() : void {
        $labels = [
            'name'               => __( 'Regole Promozioni', 'advanced-promo-mechanics' ),
            'singular_name'      => __( 'Regola Promozione', 'advanced-promo-mechanics' ),
            'add_new'            => __( 'Aggiungi nuova regola', 'advanced-promo-mechanics' ),
            'add_new_item'       => __( 'Aggiungi regola', 'advanced-promo-mechanics' ),
            'edit_item'          => __( 'Modifica regola', 'advanced-promo-mechanics' ),
            'new_item'           => __( 'Nuova regola', 'advanced-promo-mechanics' ),
            'view_item'          => __( 'Vedi regola', 'advanced-promo-mechanics' ),
            'search_items'       => __( 'Cerca regole', 'advanced-promo-mechanics' ),
            'not_found'          => __( 'Nessuna regola trovata', 'advanced-promo-mechanics' ),
            'not_found_in_trash' => __( 'Nessuna regola nel cestino', 'advanced-promo-mechanics' ),
        ];

        register_post_type( 'apm_rule', [
            'labels'          => $labels,
            'public'          => false,
            'show_ui'         => true,
            'show_in_menu'    => false,
            'capability_type' => 'shop_coupon',
            'map_meta_cap'    => true,
            'supports'        => [ 'title' ],
        ] );
    }

    public function register_settings() : void {
        register_setting( 'apm_settings', 'apm_settings', [ $this, 'sanitize_settings' ] );
    }

    public function sanitize_settings( array $input ) : array {
        $output = [
            'debug'         => ! empty( $input['debug'] ) ? 1 : 0,
            'force_gifts'   => ! empty( $input['force_gifts'] ) ? 1 : 0,
            'dry_run'       => ! empty( $input['dry_run'] ) ? 1 : 0,
        ];

        return $output;
    }

    public function maybe_flush_cache() : void {
        if ( isset( $_GET['apm_flush_rules'] ) && current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
            $this->rules_store->flush_cache();
        }
    }
}
