<?php
/**
 * Plugin Name:       Advanced Promo Mechanics
 * Plugin URI:        https://example.com/plugins/advanced-promo-mechanics
 * Description:       Gestione avanzata delle promozioni WooCommerce (omaggi, BOGO, 3x2, sconti quantità) senza rompere i totali.
 * Version:           0.1.0
 * Author:            Mariano + Mark
 * Text Domain:       advanced-promo-mechanics
 * Domain Path:       /languages
 * Requires PHP:      8.1
 * Requires at least: 6.4
 * WC tested up to:   9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'APM_VERSION', '0.1.0' );
define( 'APM_PLUGIN_FILE', __FILE__ );
define( 'APM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'APM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

autoload_apm();

/**
 * Lightweight PSR-4 style autoloader for plugin classes.
 */
function autoload_apm() : void {
    spl_autoload_register(
        static function ( $class ) {
            if ( str_starts_with( $class, 'APM\\' ) ) {
                $path = APM_PLUGIN_DIR . 'includes/' . strtolower( str_replace( [ 'APM\\', '\\' ], [ '', '/' ], $class ) ) . '.php';
                if ( file_exists( $path ) ) {
                    require_once $path;
                }
            }
        }
    );
}

add_action( 'plugins_loaded', static function () {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }

    load_plugin_textdomain( 'advanced-promo-mechanics', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

    $plugin = new APM\Plugin();
    $plugin->init();
} );
